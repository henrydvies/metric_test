Changelog
<!-- 
Add with the following format (for more information see http://docs.jellyfaas.com/changelog):
Date: 3/12/14 <- US format
Added: <some added feature description>
Updated: <some updated feature description>
Removed: <some removed feature>
-->

# Date: 01/01/24
## Added: 
**Initial** version, this is the example file

## Updated:
All features are as before, this supports:

Multiline:

* Item 1
* Item 2
* Item 2a
* Item 2b

## Removed:
Blocks of code:
```
let message = 'Hello world';
alert(message);
```

# Date: 01/03/24
## Added: 
**Second Release** version, this is the example file

## Updated:
All features are as before, this supports:
*cats*

## Removed:
Blocks of code:
```
let message = 'Hello world';
alert(message);
```

